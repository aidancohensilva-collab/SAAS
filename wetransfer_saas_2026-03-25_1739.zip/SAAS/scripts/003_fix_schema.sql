-- Add missing columns to task_cycles
ALTER TABLE task_cycles ADD COLUMN IF NOT EXISTS emoji TEXT;
ALTER TABLE task_cycles ADD COLUMN IF NOT EXISTS started_at TIMESTAMPTZ DEFAULT now();

-- Rename task_cycle_id to cycle_id in task_completions for consistency
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'task_completions' AND column_name = 'task_cycle_id'
  ) THEN
    ALTER TABLE task_completions RENAME COLUMN task_cycle_id TO cycle_id;
  END IF;
END $$;

-- Add cycle_id if it doesn't exist (in case table was created fresh)
ALTER TABLE task_completions ADD COLUMN IF NOT EXISTS cycle_id UUID REFERENCES task_cycles(id) ON DELETE CASCADE;
