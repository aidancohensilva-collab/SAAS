-- Añadir columna completed_at a task_cycles
ALTER TABLE task_cycles ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ;
