-- TaskHome: Tablas para gestión de tareas domésticas compartidas

-- 1. Lugares (places)
CREATE TABLE IF NOT EXISTS places (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  emoji TEXT,
  image_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Integrantes (members)
CREATE TABLE IF NOT EXISTS members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  place_id UUID NOT NULL REFERENCES places(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  is_claimed BOOLEAN DEFAULT FALSE,
  device_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Ciclos de tareas (task_cycles)
CREATE TABLE IF NOT EXISTS task_cycles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  place_id UUID NOT NULL REFERENCES places(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  started_by UUID NOT NULL REFERENCES members(id),
  is_completed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Completados por miembro (task_completions)
CREATE TABLE IF NOT EXISTS task_completions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_cycle_id UUID NOT NULL REFERENCES task_cycles(id) ON DELETE CASCADE,
  member_id UUID NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  completed_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(task_cycle_id, member_id)
);

-- Índices para optimizar consultas
CREATE INDEX IF NOT EXISTS idx_members_place_id ON members(place_id);
CREATE INDEX IF NOT EXISTS idx_members_device_id ON members(device_id);
CREATE INDEX IF NOT EXISTS idx_task_cycles_place_id ON task_cycles(place_id);
CREATE INDEX IF NOT EXISTS idx_task_cycles_is_completed ON task_cycles(is_completed);
CREATE INDEX IF NOT EXISTS idx_task_completions_task_cycle_id ON task_completions(task_cycle_id);
CREATE INDEX IF NOT EXISTS idx_task_completions_member_id ON task_completions(member_id);

-- Habilitar RLS (pero con políticas permisivas ya que no hay auth)
ALTER TABLE places ENABLE ROW LEVEL SECURITY;
ALTER TABLE members ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_cycles ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_completions ENABLE ROW LEVEL SECURITY;

-- Políticas permisivas (sin auth, todos pueden acceder)
CREATE POLICY "Allow all access to places" ON places FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to members" ON members FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to task_cycles" ON task_cycles FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all access to task_completions" ON task_completions FOR ALL USING (true) WITH CHECK (true);
