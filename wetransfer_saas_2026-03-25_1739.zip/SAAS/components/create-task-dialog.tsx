'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Field, FieldLabel, FieldGroup } from '@/components/ui/field'
import { createClient } from '@/lib/supabase/client'
import type { Member } from '@/lib/types'
import { Plus } from 'lucide-react'

const TASK_EMOJIS = ['🗑️', '🧹', '🍽️', '🛒', '🧺', '🚿', '🛏️', '🐕', '🌱', '📦', '🧽', '🚗']

interface CreateTaskDialogProps {
  placeId: string
  currentMember: Member
  onTaskCreated: () => void
}

export function CreateTaskDialog({ placeId, currentMember, onTaskCreated }: CreateTaskDialogProps) {
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [emoji, setEmoji] = useState('🗑️')
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) return

    setIsLoading(true)
    try {
      const supabase = createClient()

      // 1. Create the task cycle
      const { data: cycle, error: cycleError } = await supabase
        .from('task_cycles')
        .insert({
          place_id: placeId,
          name: name.trim(),
          emoji,
          started_by: currentMember.id,
        })
        .select()
        .single()

      if (cycleError) {
        console.error('Error creating cycle:', cycleError)
        return
      }

      // 2. Mark the creator as already completed (they already did the task)
      const { error: completionError } = await supabase
        .from('task_completions')
        .insert({
          cycle_id: cycle.id,
          member_id: currentMember.id,
        })

      if (completionError) {
        console.error('Error creating completion:', completionError)
      }

      setName('')
      setEmoji('🗑️')
      setOpen(false)
      onTaskCreated()
    } catch (err) {
      console.error('Error creating task:', err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg">
          <Plus className="w-6 h-6" />
          <span className="sr-only">Nueva tarea</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Nueva tarea</DialogTitle>
          <DialogDescription>
            Añade una tarea que acabas de hacer. Los demás la deberán completar.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <FieldGroup>
            <Field>
              <FieldLabel>Nombre de la tarea</FieldLabel>
              <Input
                placeholder="Ej: Tirar la basura"
                value={name}
                onChange={(e) => setName(e.target.value)}
                autoFocus
              />
            </Field>

            <Field>
              <FieldLabel>Icono</FieldLabel>
              <div className="flex flex-wrap gap-2">
                {TASK_EMOJIS.map((e) => (
                  <button
                    key={e}
                    type="button"
                    onClick={() => setEmoji(e)}
                    className={`w-10 h-10 text-xl rounded-lg transition-all ${
                      emoji === e
                        ? 'bg-primary/20 ring-2 ring-primary scale-110'
                        : 'bg-secondary hover:bg-secondary/80'
                    }`}
                  >
                    {e}
                  </button>
                ))}
              </div>
            </Field>
          </FieldGroup>

          <Button type="submit" className="w-full" disabled={isLoading || !name.trim()}>
            {isLoading ? 'Creando...' : 'Crear tarea'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}
