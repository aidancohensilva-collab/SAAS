'use client'

import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { MemberAvatar } from '@/components/member-avatar'
import { createClient } from '@/lib/supabase/client'
import type { Member, TaskCycleWithProgress } from '@/lib/types'
import { Check, Clock } from 'lucide-react'

interface TaskCardProps {
  task: TaskCycleWithProgress
  currentMember: Member
  allMembers: Member[]
  onTaskUpdated: () => void
}

export function TaskCard({ task, currentMember, allMembers, onTaskUpdated }: TaskCardProps) {
  const [isCompleting, setIsCompleting] = useState(false)

  const completedMemberIds = new Set(task.completions.map((c) => c.member_id))
  const hasCurrentMemberCompleted = completedMemberIds.has(currentMember.id)

  // Current member owes this task if they haven't completed it
  const owesTask = !hasCurrentMemberCompleted

  const handleComplete = async () => {
    if (!owesTask) return
    setIsCompleting(true)

    try {
      const supabase = createClient()

      // Add completion
      await supabase.from('task_completions').insert({
        cycle_id: task.id,
        member_id: currentMember.id,
      })

      // Check if all members have completed (starter is already in completions)
      const completionsNeeded = allMembers.length
      const currentCompletions = task.completions.length + 1

      if (currentCompletions >= completionsNeeded) {
        // Close the cycle
        await supabase
          .from('task_cycles')
          .update({ completed_at: new Date().toISOString() })
          .eq('id', task.id)
      }

      onTaskUpdated()
    } catch (err) {
      console.error('Error completing task:', err)
    } finally {
      setIsCompleting(false)
    }
  }

  // Progress: all members need to complete (including starter who is auto-completed)
  const progressPercent = Math.round(
    (task.completedCount / task.totalMembers) * 100
  )

  return (
    <Card className={`overflow-hidden transition-all ${owesTask ? 'ring-2 ring-primary/50' : ''}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="text-3xl">{task.emoji || '📋'}</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-semibold text-foreground truncate">{task.name}</h3>
              {owesTask && (
                <span className="shrink-0 px-2 py-0.5 bg-primary/10 text-primary text-xs font-medium rounded-full">
                  Te toca
                </span>
              )}
            </div>
            <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-3">
              <Clock className="w-3.5 h-3.5" />
              <span>Iniciada por {task.startedByMember?.name || 'Desconocido'}</span>
            </div>

            {/* Progress */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>Progreso del ciclo</span>
                <span>{task.completedCount} de {task.totalMembers}</span>
              </div>
              <div className="h-2 bg-secondary rounded-full overflow-hidden">
                <div
                  className="h-full bg-accent transition-all duration-500"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>

              {/* Member avatars */}
              <div className="flex items-center gap-1 flex-wrap">
                {allMembers.map((member) => {
                    const hasCompleted = completedMemberIds.has(member.id)
                    return (
                      <div key={member.id} className="relative group">
                        <MemberAvatar
                          name={member.name}
                          size="sm"
                          completed={hasCompleted}
                          className={!hasCompleted ? 'opacity-40' : ''}
                        />
                        <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-foreground text-background text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                          {member.name}
                        </div>
                      </div>
                    )
                  })}
              </div>
            </div>
          </div>

          {owesTask && (
            <Button
              size="sm"
              onClick={handleComplete}
              disabled={isCompleting}
              className="shrink-0"
            >
              <Check className="w-4 h-4 mr-1" />
              Hecho
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
