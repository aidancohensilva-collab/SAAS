'use client'

import { useState, useEffect, useCallback } from 'react'
import { MemberAvatar } from '@/components/member-avatar'
import { TaskCard } from '@/components/task-card'
import { CreateTaskDialog } from '@/components/create-task-dialog'
import { TaskHistory } from '@/components/task-history'
import { Button } from '@/components/ui/button'
import { createClient } from '@/lib/supabase/client'
import type { Member, Place, TaskCycleWithProgress, TaskCompletion } from '@/lib/types'
import { Share2, Users, CheckCircle2, History } from 'lucide-react'

interface PlaceViewProps {
  place: Place
  members: Member[]
  currentMember: Member
}

export function PlaceView({ place, members, currentMember }: PlaceViewProps) {
  const [tasks, setTasks] = useState<TaskCycleWithProgress[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [copied, setCopied] = useState(false)
  const [showHistory, setShowHistory] = useState(false)

  const fetchTasks = useCallback(async () => {
    const supabase = createClient()

    // Fetch active task cycles (not completed)
    const { data: cycles, error: cyclesError } = await supabase
      .from('task_cycles')
      .select('*')
      .eq('place_id', place.id)
      .is('completed_at', null)
      .order('started_at', { ascending: false })

    if (cyclesError) {
      console.error('Error fetching cycles:', cyclesError)
      return
    }

    if (!cycles || cycles.length === 0) {
      setTasks([])
      setIsLoading(false)
      return
    }

    // Fetch completions for all cycles
    const cycleIds = cycles.map((c) => c.id)
    const { data: completions } = await supabase
      .from('task_completions')
      .select('*')
      .in('cycle_id', cycleIds)

    // Build task objects with progress
    const tasksWithProgress: TaskCycleWithProgress[] = cycles.map((cycle) => {
      const cycleCompletions = (completions || []).filter(
        (c: TaskCompletion) => c.cycle_id === cycle.id
      )
      const startedByMember = members.find((m) => m.id === cycle.started_by) || null

      return {
        ...cycle,
        completions: cycleCompletions,
        totalMembers: members.length,
        completedCount: cycleCompletions.length,
        startedByMember,
      }
    })

    setTasks(tasksWithProgress)
    setIsLoading(false)
  }, [place.id, members])

  useEffect(() => {
    fetchTasks()
  }, [fetchTasks])

  const handleShare = async () => {
    const url = window.location.href
    try {
      if (navigator.share) {
        await navigator.share({
          title: `Unirse a ${place.name}`,
          text: `Únete a las tareas de ${place.name}`,
          url,
        })
      } else {
        await navigator.clipboard.writeText(url)
        setCopied(true)
        setTimeout(() => setCopied(false), 2000)
      }
    } catch (err) {
      console.error('Error sharing:', err)
    }
  }

  const pendingTasks = tasks.filter((t) => {
    // Show task if current member has NOT completed it yet
    const hasCompleted = t.completions.some((c) => c.member_id === currentMember.id)
    return !hasCompleted
  })

  const otherTasks = tasks.filter((t) => {
    // Show task if current member has completed it
    const hasCompleted = t.completions.some((c) => c.member_id === currentMember.id)
    return hasCompleted
  })

  // Show history view
  if (showHistory) {
    return (
      <TaskHistory
        place={place}
        members={members}
        onBack={() => setShowHistory(false)}
      />
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/95 backdrop-blur border-b border-border">
        <div className="container max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="text-3xl">{place.emoji || '🏠'}</div>
              <div>
                <h1 className="font-bold text-lg text-foreground">{place.name}</h1>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Users className="w-3.5 h-3.5" />
                  <span>{members.length} integrantes</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={() => setShowHistory(true)} title="Historial">
                <History className="w-5 h-5" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleShare}>
                <Share2 className="w-4 h-4 mr-2" />
                {copied ? 'Copiado' : 'Compartir'}
              </Button>
            </div>
          </div>

          {/* Members row */}
          <div className="flex items-center gap-2 mt-4 overflow-x-auto pb-1">
            {members.map((member) => (
              <div
                key={member.id}
                className={`flex flex-col items-center gap-1 ${
                  member.id === currentMember.id ? 'opacity-100' : 'opacity-70'
                }`}
              >
                <MemberAvatar
                  name={member.name}
                  size="md"
                  className={member.id === currentMember.id ? 'ring-2 ring-primary ring-offset-2' : ''}
                />
                <span className="text-xs text-muted-foreground whitespace-nowrap">
                  {member.id === currentMember.id ? 'Tú' : member.name.split(' ')[0]}
                </span>
              </div>
            ))}
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="container max-w-2xl mx-auto px-4 py-6 pb-24">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full" />
          </div>
        ) : tasks.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-10 h-10 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-semibold text-foreground mb-2">No hay tareas activas</h2>
            <p className="text-muted-foreground max-w-sm mx-auto">
              Cuando alguien haga una tarea (como tirar la basura), 
              aparecerá aquí para que los demás la completen.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {pendingTasks.length > 0 && (
              <section>
                <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-3">
                  Te toca ({pendingTasks.length})
                </h2>
                <div className="space-y-3">
                  {pendingTasks.map((task) => (
                    <TaskCard
                      key={task.id}
                      task={task}
                      currentMember={currentMember}
                      allMembers={members}
                      onTaskUpdated={fetchTasks}
                    />
                  ))}
                </div>
              </section>
            )}

            {otherTasks.length > 0 && (
              <section>
                <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-3">
                  Ciclos en progreso ({otherTasks.length})
                </h2>
                <div className="space-y-3">
                  {otherTasks.map((task) => (
                    <TaskCard
                      key={task.id}
                      task={task}
                      currentMember={currentMember}
                      allMembers={members}
                      onTaskUpdated={fetchTasks}
                    />
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </main>

      <CreateTaskDialog
        placeId={place.id}
        currentMember={currentMember}
        onTaskCreated={fetchTasks}
      />
    </div>
  )
}
