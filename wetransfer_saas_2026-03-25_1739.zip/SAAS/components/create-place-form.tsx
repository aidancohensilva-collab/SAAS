'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Field, FieldLabel, FieldGroup } from '@/components/ui/field'
import { MemberAvatar } from '@/components/member-avatar'
import { createClient } from '@/lib/supabase/client'
import { Plus, X, Home, Users, Sparkles } from 'lucide-react'

const EMOJI_OPTIONS = ['🏠', '🏖️', '🏔️', '🏕️', '🏢', '🎉', '✈️', '🌴', '⛷️', '🏡']

export function CreatePlaceForm() {
  const router = useRouter()
  const [name, setName] = useState('')
  const [emoji, setEmoji] = useState('🏠')
  const [members, setMembers] = useState<string[]>([''])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const addMember = () => {
    setMembers([...members, ''])
  }

  const removeMember = (index: number) => {
    if (members.length > 1) {
      setMembers(members.filter((_, i) => i !== index))
    }
  }

  const updateMember = (index: number, value: string) => {
    const updated = [...members]
    updated[index] = value
    setMembers(updated)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    const validMembers = members.filter((m) => m.trim() !== '')
    if (!name.trim()) {
      setError('El nombre del lugar es obligatorio')
      return
    }
    if (validMembers.length === 0) {
      setError('Debes añadir al menos un integrante')
      return
    }

    setIsLoading(true)

    try {
      const supabase = createClient()

      // Create place
      const { data: place, error: placeError } = await supabase
        .from('places')
        .insert({ name: name.trim(), emoji })
        .select()
        .single()

      if (placeError) throw placeError

      // Create members
      const memberInserts = validMembers.map((memberName) => ({
        place_id: place.id,
        name: memberName.trim(),
      }))

      const { error: membersError } = await supabase.from('members').insert(memberInserts)

      if (membersError) throw membersError

      // Redirect to the place
      router.push(`/lugar/${place.id}`)
    } catch (err) {
      console.error('Error creating place:', err)
      setError('Error al crear el lugar. Inténtalo de nuevo.')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-lg mx-auto shadow-lg border-0 bg-card">
      <CardHeader className="text-center pb-2">
        <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Sparkles className="w-8 h-8 text-primary" />
        </div>
        <CardTitle className="text-2xl">Crear nuevo lugar</CardTitle>
        <CardDescription>
          Crea un lugar y añade a los integrantes. Luego comparte el enlace.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <FieldGroup>
            <Field>
              <FieldLabel className="flex items-center gap-2">
                <Home className="w-4 h-4" />
                Nombre del lugar
              </FieldLabel>
              <Input
                placeholder="Ej: Vacaciones Mallorca"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="text-base"
              />
            </Field>

            <Field>
              <FieldLabel>Icono</FieldLabel>
              <div className="flex flex-wrap gap-2">
                {EMOJI_OPTIONS.map((e) => (
                  <button
                    key={e}
                    type="button"
                    onClick={() => setEmoji(e)}
                    className={`w-10 h-10 text-xl rounded-lg transition-all ${
                      emoji === e
                        ? 'bg-primary/20 ring-2 ring-primary scale-110'
                        : 'bg-secondary hover:bg-secondary/80'
                    }`}
                  >
                    {e}
                  </button>
                ))}
              </div>
            </Field>

            <Field>
              <FieldLabel className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                Integrantes
              </FieldLabel>
              <div className="space-y-3">
                {members.map((member, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <MemberAvatar name={member || '?'} size="sm" />
                    <Input
                      placeholder={index === 0 ? 'Tu nombre' : `Integrante ${index + 1}`}
                      value={member}
                      onChange={(e) => updateMember(index, e.target.value)}
                      className="flex-1"
                    />
                    {members.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeMember(index)}
                        className="text-muted-foreground hover:text-destructive"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
                <Button
                  type="button"
                  variant="outline"
                  onClick={addMember}
                  className="w-full border-dashed"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Añadir integrante
                </Button>
              </div>
            </Field>
          </FieldGroup>

          {error && (
            <div className="p-3 bg-destructive/10 text-destructive text-sm rounded-lg">
              {error}
            </div>
          )}

          <Button type="submit" className="w-full h-12 text-base" disabled={isLoading}>
            {isLoading ? 'Creando...' : 'Crear lugar'}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
