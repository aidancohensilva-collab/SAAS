'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { MemberAvatar } from '@/components/member-avatar'
import { createClient } from '@/lib/supabase/client'
import { getDeviceId, setMemberIdForPlace } from '@/lib/device'
import type { Member, Place } from '@/lib/types'
import { UserCheck } from 'lucide-react'

interface SelectMemberProps {
  place: Place
  members: Member[]
  onMemberSelected: (member: Member) => void
}

export function SelectMember({ place, members, onMemberSelected }: SelectMemberProps) {
  const [isSelecting, setIsSelecting] = useState(false)

  const handleSelectMember = async (member: Member) => {
    setIsSelecting(true)
    try {
      const supabase = createClient()
      const deviceId = getDeviceId()

      // Update member with device_id
      await supabase
        .from('members')
        .update({ device_id: deviceId })
        .eq('id', member.id)

      // Save locally
      setMemberIdForPlace(place.id, member.id)

      onMemberSelected(member)
    } catch (err) {
      console.error('Error selecting member:', err)
    } finally {
      setIsSelecting(false)
    }
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg border-0">
        <CardHeader className="text-center">
          <div className="text-5xl mb-4">{place.emoji || '🏠'}</div>
          <CardTitle className="text-2xl">{place.name}</CardTitle>
          <CardDescription className="flex items-center justify-center gap-2">
            <UserCheck className="w-4 h-4" />
            Selecciona tu nombre
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {members.map((member) => (
              <button
                key={member.id}
                onClick={() => handleSelectMember(member)}
                disabled={isSelecting || !!member.device_id}
                className={`w-full p-4 rounded-xl flex items-center gap-4 transition-all ${
                  member.device_id
                    ? 'bg-muted/50 cursor-not-allowed opacity-60'
                    : 'bg-secondary hover:bg-secondary/80 hover:scale-[1.02] active:scale-[0.98]'
                }`}
              >
                <MemberAvatar name={member.name} size="lg" />
                <div className="flex-1 text-left">
                  <div className="font-medium text-foreground">{member.name}</div>
                  {member.device_id && (
                    <div className="text-sm text-muted-foreground">Ya conectado</div>
                  )}
                </div>
                {!member.device_id && (
                  <div className="text-primary font-medium">Soy yo</div>
                )}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
