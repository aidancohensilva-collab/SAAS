'use client'

import { useState, useEffect } from 'react'
import { SelectMember } from '@/components/select-member'
import { PlaceView } from '@/components/place-view'
import { getMemberIdForPlace } from '@/lib/device'
import type { Member, Place } from '@/lib/types'

interface PlaceClientProps {
  place: Place
  members: Member[]
}

export function PlaceClient({ place, members }: PlaceClientProps) {
  const [currentMember, setCurrentMember] = useState<Member | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user has already selected their identity
    const savedMemberId = getMemberIdForPlace(place.id)
    
    if (savedMemberId) {
      const member = members.find((m) => m.id === savedMemberId)
      if (member) {
        setCurrentMember(member)
      }
    }
    
    setIsLoading(false)
  }, [place.id, members])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    )
  }

  if (!currentMember) {
    return (
      <SelectMember
        place={place}
        members={members}
        onMemberSelected={setCurrentMember}
      />
    )
  }

  return (
    <PlaceView
      place={place}
      members={members}
      currentMember={currentMember}
    />
  )
}
