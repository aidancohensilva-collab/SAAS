'use client'

import { useState, useEffect, useCallback } from 'react'
import { MemberAvatar } from '@/components/member-avatar'
import { createClient } from '@/lib/supabase/client'
import type { Member, Place } from '@/lib/types'
import { Clock, ArrowLeft, CheckCircle2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'

interface HistoryEntry {
  id: string
  cycle_id: string
  member_id: string
  completed_at: string
  task_name: string
  task_emoji: string | null
  member: Member | null
}

interface TaskHistoryProps {
  place: Place
  members: Member[]
  onBack: () => void
}

export function TaskHistory({ place, members, onBack }: TaskHistoryProps) {
  const [history, setHistory] = useState<HistoryEntry[]>([])
  const [isLoading, setIsLoading] = useState(true)

  const fetchHistory = useCallback(async () => {
    const supabase = createClient()

    // Fetch all completions with their task info
    const { data: completions, error } = await supabase
      .from('task_completions')
      .select(`
        id,
        cycle_id,
        member_id,
        completed_at,
        task_cycles!inner (
          id,
          name,
          emoji,
          place_id
        )
      `)
      .eq('task_cycles.place_id', place.id)
      .order('completed_at', { ascending: false })

    if (error) {
      console.error('Error fetching history:', error)
      setIsLoading(false)
      return
    }

    const historyEntries: HistoryEntry[] = (completions || []).map((c: any) => ({
      id: c.id,
      cycle_id: c.cycle_id,
      member_id: c.member_id,
      completed_at: c.completed_at,
      task_name: c.task_cycles.name,
      task_emoji: c.task_cycles.emoji,
      member: members.find((m) => m.id === c.member_id) || null,
    }))

    setHistory(historyEntries)
    setIsLoading(false)
  }, [place.id, members])

  useEffect(() => {
    fetchHistory()
  }, [fetchHistory])

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)
    const diffHours = Math.floor(diffMs / 3600000)
    const diffDays = Math.floor(diffMs / 86400000)

    if (diffMins < 1) return 'Ahora mismo'
    if (diffMins < 60) return `Hace ${diffMins} min`
    if (diffHours < 24) return `Hace ${diffHours}h`
    if (diffDays < 7) return `Hace ${diffDays} dias`

    return date.toLocaleDateString('es-ES', {
      day: 'numeric',
      month: 'short',
      year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
    })
  }

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleTimeString('es-ES', {
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const formatFullDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('es-ES', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    })
  }

  // Group by date
  const groupedHistory = history.reduce((acc, entry) => {
    const date = new Date(entry.completed_at).toDateString()
    if (!acc[date]) {
      acc[date] = []
    }
    acc[date].push(entry)
    return acc
  }, {} as Record<string, HistoryEntry[]>)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background/95 backdrop-blur border-b border-border">
        <div className="container max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-bold text-lg text-foreground">Historial</h1>
              <p className="text-sm text-muted-foreground">{place.name}</p>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="container max-w-2xl mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full" />
          </div>
        ) : history.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-10 h-10 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-semibold text-foreground mb-2">Sin historial</h2>
            <p className="text-muted-foreground max-w-sm mx-auto">
              Aqui apareceran todas las tareas completadas con fecha y hora.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedHistory).map(([dateKey, entries]) => (
              <section key={dateKey}>
                <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-3 flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  {formatFullDate(entries[0].completed_at)}
                </h2>
                <div className="space-y-2">
                  {entries.map((entry) => (
                    <Card key={entry.id} className="p-4">
                      <div className="flex items-center gap-3">
                        <MemberAvatar
                          name={entry.member?.name || 'Usuario'}
                          size="md"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{entry.task_emoji || '📋'}</span>
                            <span className="font-medium text-foreground truncate">
                              {entry.task_name}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            <span className="font-medium">{entry.member?.name || 'Usuario'}</span>
                            {' '}completo esta tarea
                          </p>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="flex items-center gap-1 text-accent">
                            <CheckCircle2 className="w-4 h-4" />
                            <span className="text-sm font-medium">{formatTime(entry.completed_at)}</span>
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {formatDate(entry.completed_at)}
                          </span>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </section>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
