import { CreatePlaceForm } from '@/components/create-place-form'

export default function HomePage() {
  return (
    <main className="min-h-screen bg-background">
      <div className="container max-w-4xl mx-auto px-4 py-12">
        <header className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-3">
            TaskHome
          </h1>
          <p className="text-lg text-muted-foreground max-w-md mx-auto text-pretty">
            Organiza las tareas del hogar de forma justa. Cuando alguien hace una tarea, 
            los demás la deben hasta que todos completen el ciclo.
          </p>
        </header>
        
        <CreatePlaceForm />
        
        <footer className="mt-16 text-center text-sm text-muted-foreground">
          <p>Sin registro. Sin fricción. Solo comparte el enlace.</p>
        </footer>
      </div>
    </main>
  )
}
