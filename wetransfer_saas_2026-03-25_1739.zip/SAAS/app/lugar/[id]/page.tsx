import { notFound } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { PlaceClient } from '@/components/place-client'
import type { Place, Member } from '@/lib/types'

interface PageProps {
  params: Promise<{ id: string }>
}

export async function generateMetadata({ params }: PageProps) {
  const { id } = await params
  const supabase = await createClient()
  
  const { data: place } = await supabase
    .from('places')
    .select('name, emoji')
    .eq('id', id)
    .single()

  if (!place) {
    return { title: 'Lugar no encontrado' }
  }

  return {
    title: `${place.emoji || '🏠'} ${place.name} - TaskHome`,
    description: `Gestiona las tareas de ${place.name}`,
  }
}

export default async function PlacePage({ params }: PageProps) {
  const { id } = await params
  const supabase = await createClient()

  // Fetch place
  const { data: place, error: placeError } = await supabase
    .from('places')
    .select('*')
    .eq('id', id)
    .single()

  if (placeError || !place) {
    notFound()
  }

  // Fetch members
  const { data: members, error: membersError } = await supabase
    .from('members')
    .select('*')
    .eq('place_id', id)
    .order('created_at', { ascending: true })

  if (membersError) {
    console.error('Error fetching members:', membersError)
  }

  return (
    <PlaceClient
      place={place as Place}
      members={(members || []) as Member[]}
    />
  )
}
