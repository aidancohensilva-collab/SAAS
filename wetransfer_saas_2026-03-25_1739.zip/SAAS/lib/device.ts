'use client'

const DEVICE_ID_KEY = 'taskhome_device_id'

export function getDeviceId(): string {
  if (typeof window === 'undefined') return ''
  
  let deviceId = localStorage.getItem(DEVICE_ID_KEY)
  
  if (!deviceId) {
    deviceId = crypto.randomUUID()
    localStorage.setItem(DEVICE_ID_KEY, deviceId)
  }
  
  return deviceId
}

export function getMemberIdForPlace(placeId: string): string | null {
  if (typeof window === 'undefined') return null
  return localStorage.getItem(`taskhome_member_${placeId}`)
}

export function setMemberIdForPlace(placeId: string, memberId: string): void {
  if (typeof window === 'undefined') return
  localStorage.setItem(`taskhome_member_${placeId}`, memberId)
}
