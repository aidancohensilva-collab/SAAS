export interface Place {
  id: string
  name: string
  emoji: string | null
  image_url: string | null
  created_at: string
}

export interface Member {
  id: string
  place_id: string
  name: string
  avatar_url: string | null
  device_id: string | null
  created_at: string
}

export interface TaskCycle {
  id: string
  place_id: string
  name: string
  emoji: string | null
  started_by: string
  started_at: string
  completed_at: string | null
}

export interface TaskCompletion {
  id: string
  cycle_id: string
  member_id: string
  completed_at: string
}

export interface TaskCycleWithProgress extends TaskCycle {
  completions: TaskCompletion[]
  totalMembers: number
  completedCount: number
  startedByMember: Member | null
}
